import React from 'react';
import { Menu, Search, Bell, User } from 'lucide-react';
import { useSidebar } from '../contexts/SidebarContext';
import { useProfile } from '../contexts/ProfileContext';
import { ProfileModal } from './ProfileModal';

export function Navbar() {
  const { toggle } = useSidebar();
  const { toggleProfile } = useProfile();

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white border-b z-50">
      <div className="flex items-center justify-between px-4 h-14">
        <div className="flex items-center gap-4">
          <button 
            onClick={toggle}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <Menu size={24} />
          </button>
          <h1 className="text-xl font-bold">StreamHub</h1>
        </div>
        
        <div className="flex-1 max-w-2xl mx-4">
          <div className="flex">
            <input
              type="text"
              placeholder="Search"
              className="w-full px-4 py-2 border border-gray-300 rounded-l-full focus:outline-none focus:border-blue-500"
            />
            <button className="px-6 bg-gray-100 border border-l-0 border-gray-300 rounded-r-full hover:bg-gray-200">
              <Search size={20} />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-full">
            <Bell size={24} />
          </button>
          <div className="relative">
            <button 
              onClick={toggleProfile}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <User size={24} />
            </button>
            <ProfileModal />
          </div>
        </div>
      </div>
    </nav>
  );
}