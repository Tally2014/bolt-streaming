import React from 'react';
import { VideoCard } from './VideoCard';

const videos = [
  {
    thumbnail: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
    title: "Building a Modern Web Application with React and TypeScript",
    channel: "Tech Academy",
    views: "125K",
    timestamp: "2 days ago"
  },
  {
    thumbnail: "https://images.unsplash.com/photo-1516116216624-53e697fedbea",
    title: "5 Essential Photography Tips for Beginners",
    channel: "Photo Masters",
    views: "89K",
    timestamp: "1 week ago"
  },
  {
    thumbnail: "https://images.unsplash.com/photo-1511379938547-c1f69419868d",
    title: "Music Production Masterclass: From Basics to Advanced",
    channel: "Music Studio",
    views: "203K",
    timestamp: "3 days ago"
  },
  {
    thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97",
    title: "Complete Guide to Software Development in 2024",
    channel: "Code Masters",
    views: "156K",
    timestamp: "5 days ago"
  },
  {
    thumbnail: "https://images.unsplash.com/photo-1526925539332-aa3b66e35444",
    title: "Digital Art Creation: Tips and Techniques",
    channel: "Art Studio",
    views: "92K",
    timestamp: "1 day ago"
  },
  {
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f",
    title: "Marketing Strategies for Small Businesses",
    channel: "Business Hub",
    views: "78K",
    timestamp: "4 days ago"
  }
];

export function VideoGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
      {videos.map((video, index) => (
        <VideoCard key={index} {...video} />
      ))}
    </div>
  );
}