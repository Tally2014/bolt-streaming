import React from 'react';
import { MoreVertical } from 'lucide-react';

interface VideoCardProps {
  thumbnail: string;
  title: string;
  channel: string;
  views: string;
  timestamp: string;
}

export function VideoCard({ thumbnail, title, channel, views, timestamp }: VideoCardProps) {
  return (
    <div className="flex flex-col gap-2">
      <div className="relative aspect-video rounded-xl overflow-hidden group">
        <img
          src={thumbnail}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-2 right-2 bg-black text-white text-sm px-2 py-1 rounded">
          12:34
        </div>
      </div>
      
      <div className="flex gap-3">
        <img
          className="w-9 h-9 rounded-full"
          src={`https://ui-avatars.com/api/?name=${channel}&background=random`}
          alt={channel}
        />
        <div className="flex-1">
          <h3 className="font-semibold line-clamp-2">{title}</h3>
          <p className="text-sm text-gray-600">{channel}</p>
          <p className="text-sm text-gray-600">
            {views} views • {timestamp}
          </p>
        </div>
        <button className="p-2 hover:bg-gray-100 rounded-full self-start">
          <MoreVertical size={20} />
        </button>
      </div>
    </div>
  );
}