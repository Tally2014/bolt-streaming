import React from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { VideoGrid } from './components/VideoGrid';
import { SidebarProvider } from './contexts/SidebarContext';
import { ProfileProvider } from './contexts/ProfileContext';
import { useSidebar } from './contexts/SidebarContext';

function MainContent() {
  const { isOpen } = useSidebar();
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="flex pt-14">
        <Sidebar />
        <main className={`flex-1 transition-all duration-300 ${isOpen ? 'ml-64' : 'ml-16'}`}>
          <VideoGrid />
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <SidebarProvider>
      <ProfileProvider>
        <MainContent />
      </ProfileProvider>
    </SidebarProvider>
  );
}

export default App;