import React, { useRef, useEffect } from 'react';
import { Settings, LogOut, User as UserIcon } from 'lucide-react';
import { useProfile } from '../contexts/ProfileContext';

export function ProfileModal() {
  const { isProfileOpen, closeProfile } = useProfile();
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        closeProfile();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [closeProfile]);

  if (!isProfileOpen) return null;

  return (
    <div className="absolute top-12 right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50" ref={modalRef}>
      <div className="px-4 py-3 border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
            <UserIcon size={20} className="text-gray-600" />
          </div>
          <div>
            <p className="font-medium">John Doe</p>
            <p className="text-sm text-gray-600">john@example.com</p>
          </div>
        </div>
      </div>
      
      <button className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-100 transition-colors">
        <Settings size={18} />
        <span>Settings</span>
      </button>
      
      <button className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-100 text-red-600 transition-colors">
        <LogOut size={18} />
        <span>Sign Out</span>
      </button>
    </div>
  );
}