import React from 'react';
import { Home, Compass, Clock, ThumbsUp, PlaySquare, History } from 'lucide-react';
import { useSidebar } from '../contexts/SidebarContext';

const menuItems = [
  { icon: Home, label: 'Home' },
  { icon: Compass, label: 'Explore' },
  { icon: Clock, label: 'Shorts' },
  { icon: PlaySquare, label: 'Library' },
  { icon: History, label: 'History' },
  { icon: ThumbsUp, label: 'Liked' },
];

export function Sidebar() {
  const { isOpen } = useSidebar();

  return (
    <aside className={`fixed left-0 top-14 h-[calc(100vh-3.5rem)] bg-white border-r p-2 overflow-y-auto transition-all duration-300 ${
      isOpen ? 'w-64' : 'w-16'
    }`}>
      {menuItems.map(({ icon: Icon, label }) => (
        <button
          key={label}
          className="flex items-center gap-4 w-full p-3 hover:bg-gray-100 rounded-lg"
        >
          <Icon size={24} />
          <span className={`${isOpen ? 'opacity-100' : 'opacity-0 hidden'} transition-opacity duration-300`}>
            {label}
          </span>
        </button>
      ))}
    </aside>
  );
}